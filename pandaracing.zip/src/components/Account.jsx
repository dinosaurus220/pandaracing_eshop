import React from 'react'

function Account() {
  return (
    <div>Account</div>
  )
}

export default Account