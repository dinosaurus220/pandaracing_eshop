import Close from './close.png';
import Menu from './menuv2.svg';
import Logo from './pandaracev3.png';

export {
    Close,
    Menu,
    Logo
}